# Closed-loop Matters: Dual Regression Networks for Single Image Super-Resolution

Pytorch implementation for "Closed-loop Matters: Dual Regression Networks for Single Image Super-Resolution".



![dual](imgs/dual.png)



### We will release the code and pretrained models in a few days.
